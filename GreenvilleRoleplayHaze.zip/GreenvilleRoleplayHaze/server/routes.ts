import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { discordBot } from "./discord/bot";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Bot status endpoint
  app.get("/api/bot/status", async (_req, res) => {
    const status = discordBot.getStatus();
    res.json(status);
  });

  // Get active session
  app.get("/api/sessions/active", async (_req, res) => {
    const session = await storage.getActiveSession();
    res.json(session || null);
  });

  // Get all active sessions
  app.get("/api/sessions", async (_req, res) => {
    const sessions = await storage.getAllSessions();
    res.json(sessions);
  });

  // Get completed sessions
  app.get("/api/sessions/completed", async (_req, res) => {
    const sessions = await storage.getCompletedSessions();
    res.json(sessions);
  });

  // Get all hosts with their session summaries
  app.get("/api/hosts", async (_req, res) => {
    const hosts = await storage.getAllHosts();
    res.json(hosts);
  });

  // Search hosts by name
  app.get("/api/hosts/search", async (req, res) => {
    const query = req.query.q as string || "";
    if (!query) {
      const allHosts = await storage.getAllHosts();
      res.json(allHosts);
      return;
    }
    const hosts = await storage.searchHosts(query);
    res.json(hosts);
  });

  // Get specific host summary
  app.get("/api/hosts/:hostId", async (req, res) => {
    const summary = await storage.getHostSummary(req.params.hostId);
    if (!summary) {
      res.status(404).json({ error: "Host not found" });
      return;
    }
    res.json(summary);
  });

  // Get sessions by host
  app.get("/api/hosts/:hostId/sessions", async (req, res) => {
    const sessions = await storage.getSessionsByHost(req.params.hostId);
    res.json(sessions);
  });

  // Register slash commands for a guild
  app.post("/api/bot/register-commands", async (req, res) => {
    const { guildId } = req.body;
    try {
      await discordBot.registerCommands(guildId);
      res.json({ success: true, message: "Commands registered successfully" });
    } catch (error: any) {
      res.status(500).json({ success: false, message: error.message });
    }
  });

  // Get registered vehicles for a user
  app.get("/api/vehicles/:userId", async (req, res) => {
    const vehicles = await storage.getVehiclesByUser(req.params.userId);
    res.json(vehicles);
  });

  return httpServer;
}

import { 
  type SessionState, 
  type InsertSessionState, 
  type VehicleRegistration,
  type CompletedSession,
  type InsertCompletedSession,
  type HostSummary 
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  createSession(session: InsertSessionState): Promise<SessionState>;
  getSession(id: string): Promise<SessionState | undefined>;
  getSessionByChannel(channelId: string): Promise<SessionState | undefined>;
  getActiveSession(): Promise<SessionState | undefined>;
  updateSession(id: string, updates: Partial<SessionState>): Promise<SessionState | undefined>;
  addReactedUser(sessionId: string, odiscordUserId: string): Promise<void>;
  hasUserReacted(sessionId: string, odiscordUserId: string): Promise<boolean>;
  deleteSession(id: string): Promise<void>;
  getAllSessions(): Promise<SessionState[]>;
  registerVehicle(registration: Omit<VehicleRegistration, "id" | "registeredAt">): Promise<VehicleRegistration>;
  getVehiclesByUser(odiscordUserId: string): Promise<VehicleRegistration[]>;
  
  logCompletedSession(session: InsertCompletedSession): Promise<CompletedSession>;
  getCompletedSessions(): Promise<CompletedSession[]>;
  getSessionsByHost(hostId: string): Promise<CompletedSession[]>;
  getHostSummary(hostId: string): Promise<HostSummary | undefined>;
  searchHosts(query: string): Promise<HostSummary[]>;
  getAllHosts(): Promise<HostSummary[]>;
}

export class MemStorage implements IStorage {
  private sessions: Map<string, SessionState>;
  private vehicles: Map<string, VehicleRegistration>;
  private completedSessions: Map<string, CompletedSession>;

  constructor() {
    this.sessions = new Map();
    this.vehicles = new Map();
    this.completedSessions = new Map();
  }

  async createSession(insertSession: InsertSessionState): Promise<SessionState> {
    const id = randomUUID();
    const session: SessionState = {
      ...insertSession,
      id,
      createdAt: new Date().toISOString(),
    };
    this.sessions.set(id, session);
    return session;
  }

  async getSession(id: string): Promise<SessionState | undefined> {
    return this.sessions.get(id);
  }

  async getSessionByChannel(channelId: string): Promise<SessionState | undefined> {
    return Array.from(this.sessions.values()).find(
      (session) => session.channelId === channelId && session.status !== "ended"
    );
  }

  async getActiveSession(): Promise<SessionState | undefined> {
    return Array.from(this.sessions.values()).find(
      (session) => session.status !== "ended"
    );
  }

  async updateSession(id: string, updates: Partial<SessionState>): Promise<SessionState | undefined> {
    const session = this.sessions.get(id);
    if (!session) return undefined;
    
    const updatedSession = { ...session, ...updates };
    this.sessions.set(id, updatedSession);
    return updatedSession;
  }

  async addReactedUser(sessionId: string, odiscordUserId: string): Promise<void> {
    const session = this.sessions.get(sessionId);
    if (session && !session.reactedUsers.includes(odiscordUserId)) {
      session.reactedUsers.push(odiscordUserId);
      this.sessions.set(sessionId, session);
    }
  }

  async hasUserReacted(sessionId: string, odiscordUserId: string): Promise<boolean> {
    const session = this.sessions.get(sessionId);
    return session ? session.reactedUsers.includes(odiscordUserId) : false;
  }

  async deleteSession(id: string): Promise<void> {
    this.sessions.delete(id);
  }

  async getAllSessions(): Promise<SessionState[]> {
    return Array.from(this.sessions.values());
  }

  async registerVehicle(registration: Omit<VehicleRegistration, "id" | "registeredAt">): Promise<VehicleRegistration> {
    const id = randomUUID();
    const vehicle: VehicleRegistration = {
      ...registration,
      id,
      registeredAt: new Date().toISOString(),
    };
    this.vehicles.set(id, vehicle);
    return vehicle;
  }

  async getVehiclesByUser(odiscordUserId: string): Promise<VehicleRegistration[]> {
    return Array.from(this.vehicles.values()).filter(
      (v) => v.odiscordUserId === odiscordUserId
    );
  }

  async logCompletedSession(sessionData: InsertCompletedSession): Promise<CompletedSession> {
    const id = randomUUID();
    const completedSession: CompletedSession = {
      ...sessionData,
      id,
    };
    this.completedSessions.set(id, completedSession);
    return completedSession;
  }

  async getCompletedSessions(): Promise<CompletedSession[]> {
    return Array.from(this.completedSessions.values()).sort(
      (a, b) => new Date(b.completedAt).getTime() - new Date(a.completedAt).getTime()
    );
  }

  async getSessionsByHost(hostId: string): Promise<CompletedSession[]> {
    return Array.from(this.completedSessions.values())
      .filter((s) => s.hostId === hostId)
      .sort((a, b) => new Date(b.completedAt).getTime() - new Date(a.completedAt).getTime());
  }

  async getHostSummary(hostId: string): Promise<HostSummary | undefined> {
    const hostSessions = await this.getSessionsByHost(hostId);
    if (hostSessions.length === 0) return undefined;

    const firstSession = hostSessions[0];
    return {
      hostId,
      hostName: firstSession.hostName,
      totalSessions: hostSessions.length,
      lastSessionDate: firstSession.completedAt,
      sessions: hostSessions,
    };
  }

  async searchHosts(query: string): Promise<HostSummary[]> {
    const allSessions = Array.from(this.completedSessions.values());
    const hostMap = new Map<string, CompletedSession[]>();

    for (const session of allSessions) {
      if (session.hostName.toLowerCase().includes(query.toLowerCase())) {
        const existing = hostMap.get(session.hostId) || [];
        existing.push(session);
        hostMap.set(session.hostId, existing);
      }
    }

    const summaries: HostSummary[] = [];
    const entries = Array.from(hostMap.entries());
    for (const entry of entries) {
      const hostId = entry[0];
      const sessions = entry[1];
      const sortedSessions = sessions.sort(
        (a: CompletedSession, b: CompletedSession) => new Date(b.completedAt).getTime() - new Date(a.completedAt).getTime()
      );
      summaries.push({
        hostId,
        hostName: sortedSessions[0].hostName,
        totalSessions: sessions.length,
        lastSessionDate: sortedSessions[0].completedAt,
        sessions: sortedSessions,
      });
    }

    return summaries.sort((a, b) => b.totalSessions - a.totalSessions);
  }

  async getAllHosts(): Promise<HostSummary[]> {
    const allSessions = Array.from(this.completedSessions.values());
    const hostMap = new Map<string, CompletedSession[]>();

    for (const session of allSessions) {
      const existing = hostMap.get(session.hostId) || [];
      existing.push(session);
      hostMap.set(session.hostId, existing);
    }

    const summaries: HostSummary[] = [];
    const entries = Array.from(hostMap.entries());
    for (const entry of entries) {
      const hostId = entry[0];
      const sessions = entry[1];
      const sortedSessions = sessions.sort(
        (a: CompletedSession, b: CompletedSession) => new Date(b.completedAt).getTime() - new Date(a.completedAt).getTime()
      );
      summaries.push({
        hostId,
        hostName: sortedSessions[0].hostName,
        totalSessions: sessions.length,
        lastSessionDate: sortedSessions[0].completedAt,
        sessions: sortedSessions,
      });
    }

    return summaries.sort((a, b) => b.totalSessions - a.totalSessions);
  }
}

export const storage = new MemStorage();

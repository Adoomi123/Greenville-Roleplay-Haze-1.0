import {
  Client,
  GatewayIntentBits,
  REST,
  Routes,
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  PermissionFlagsBits,
  Events,
  type ChatInputCommandInteraction,
  type ButtonInteraction,
  type StringSelectMenuInteraction,
  type ModalSubmitInteraction,
  type MessageReaction,
  type User,
  type PartialMessageReaction,
  type PartialUser,
} from "discord.js";
import { storage } from "../storage";
import { EMOJIS, EMBED_COLOR, SESSION_IMAGES, ROLE_IDS, CHANNEL_IDS } from "@shared/schema";

const BOT_TOKEN = process.env.DISCORD_BOT_TOKEN;
const CLIENT_ID = process.env.DISCORD_CLIENT_ID;

export class DiscordBot {
  private client: Client;
  private rest: REST;
  private isReady = false;

  constructor() {
    this.client = new Client({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
      ],
    });

    this.rest = new REST({ version: "10" });

    this.setupEventHandlers();
  }

  private setupEventHandlers() {
    this.client.once(Events.ClientReady, (c) => {
      console.log(`Discord bot logged in as ${c.user.tag}`);
      this.isReady = true;
    });

    this.client.on(Events.InteractionCreate, async (interaction) => {
      try {
        if (interaction.isChatInputCommand()) {
          await this.handleSlashCommand(interaction);
        } else if (interaction.isButton()) {
          await this.handleButtonInteraction(interaction);
        } else if (interaction.isStringSelectMenu()) {
          await this.handleSelectMenuInteraction(interaction);
        } else if (interaction.isModalSubmit()) {
          await this.handleModalSubmit(interaction);
        }
      } catch (error) {
        console.error("Error handling interaction:", error);
        if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
          await interaction.reply({
            content: "An error occurred while processing your request.",
            ephemeral: true,
          });
        }
      }
    });

    this.client.on(Events.MessageReactionAdd, async (reaction, user) => {
      await this.handleReactionAdd(reaction, user);
    });
  }

  private async handleReactionAdd(
    reaction: MessageReaction | PartialMessageReaction,
    user: User | PartialUser
  ) {
    if (user.bot) return;

    const session = await storage.getActiveSession();
    if (!session || session.startupMessageId !== reaction.message.id) return;

    await storage.addReactedUser(session.id, user.id);
  }

  private async handleSlashCommand(interaction: ChatInputCommandInteraction) {
    const { commandName } = interaction;

    switch (commandName) {
      case "startup":
        await this.handleStartup(interaction);
        break;
      case "setup":
        await this.handleSetup(interaction);
        break;
      case "early-access":
        await this.handleEarlyAccess(interaction);
        break;
      case "release":
        await this.handleRelease(interaction);
        break;
      case "re-invites":
        await this.handleReinvites(interaction);
        break;
      case "link-regenerated":
        await this.handleLinkRegenerated(interaction);
        break;
      case "link-open":
        await this.handleLinkOpen(interaction);
        break;
      case "session-over":
        await this.handleSessionOver(interaction);
        break;
      case "srp-highway":
        await this.handleSrpHighway(interaction);
        break;
      case "srp-dual":
        await this.handleSrpDual(interaction);
        break;
      case "srp-construction":
        await this.handleSrpConstruction(interaction);
        break;
      case "srp-carmeet":
        await this.handleSrpCarmeet(interaction);
        break;
      case "srp-school":
        await this.handleSrpSchool(interaction);
        break;
      case "register":
        await this.handleRegister(interaction);
        break;
    }
  }

  private async handleStartup(interaction: ChatInputCommandInteraction) {
    const hostName = interaction.user.displayName || interaction.user.username;

    const embed = new EmbedBuilder()
      .setColor(EMBED_COLOR)
      .setDescription(
        `${EMOJIS.ROAD} **Greenville Roleplay Haze | Session Startup** ${EMOJIS.ROAD}\n\n` +
        `${hostName} is currently hosting a Greenville Roleplay Haze session. Please have patience while the host prepares, considering various factors that are involved with hosting a roleplay session.\n\n` +
        `Before you join.. Ensure you do the following:\n\n` +
        `${EMOJIS.ARROW} Read over our <#${CHANNEL_IDS.REGULATIONS}> channel.\n\n` +
        `${EMOJIS.ARROW} Ensure you have registered your vehicle(s) by using the command /register in <#${CHANNEL_IDS.BOT_COMMANDS}>.\n\n` +
        `${EMOJIS.ARROW} Ensure that your account is able to join private servers.\n\n` +
        `${EMOJIS.ARROW} In order for the host to setup the session this message needs a minimum of 6+ Reactions.`
      )
      .setImage(SESSION_IMAGES.STARTUP);

    await interaction.reply({
      content: `<@&${ROLE_IDS.CIVILIAN}>`,
      embeds: [embed],
      allowedMentions: { roles: [ROLE_IDS.CIVILIAN] },
    });

    const message = await interaction.fetchReply();

    await message.react(EMOJIS.TICK.match(/:(\d+)>/)?.[1] || "✅");

    const session = await storage.createSession({
      startupMessageId: message.id,
      channelId: interaction.channelId,
      hostId: interaction.user.id,
      hostName,
      status: "startup",
      sessionLink: null,
      frpSpeed: null,
      peacetimeStatus: null,
      speedLimit: null,
      houseClaiming: null,
      reactedUsers: [],
    });

    console.log(`Session created: ${session.id}`);
  }

  private async handleSetup(interaction: ChatInputCommandInteraction) {
    const session = await storage.getActiveSession();
    if (!session) {
      await interaction.reply({
        content: "No active session found. Please run /startup first.",
        ephemeral: true,
      });
      return;
    }

    const embed = new EmbedBuilder()
      .setColor(EMBED_COLOR)
      .setDescription(
        `${EMOJIS.CAR} **Greenville Roleplay Haze | Session Setup** ${EMOJIS.CAR}\n\n` +
        `${EMOJIS.ARROW} ${session.hostName} is now setting up their Roleplay Session! Please allow 10 minutes for the host to setup the session!`
      )
      .setImage(SESSION_IMAGES.SETUP);

    await interaction.reply({ embeds: [embed] });
    await storage.updateSession(session.id, { status: "setup" });
  }

  private async handleEarlyAccess(interaction: ChatInputCommandInteraction) {
    const link = interaction.options.getString("link", true);
    
    const session = await storage.getActiveSession();
    if (!session) {
      await interaction.reply({
        content: "No active session found. Please run /startup first.",
        ephemeral: true,
      });
      return;
    }

    const embed = new EmbedBuilder()
      .setColor(EMBED_COLOR)
      .setDescription(
        `${EMOJIS.LINK} **Greenville Roleplay Haze | Early Access** ${EMOJIS.LINK}\n\n` +
        `${EMOJIS.ARROW} ${session.hostName} Has released Early Access! Once you have entered, ensure you are parked up and have correct roles for your vehicles. Please remain parked until the host instructs everyone to complete the checkpoint.\n\n` +
        `${EMOJIS.DOT} Any leaking of the Early Access link will lead to a severe moderation.`
      )
      .setImage(SESSION_IMAGES.EARLY_ACCESS);

    const button = new ButtonBuilder()
      .setCustomId(`early_access_${session.id}`)
      .setLabel("Early Access")
      .setEmoji(EMOJIS.EXTERNAL.match(/<:(\w+):(\d+)>/)?.[2] || "🔗")
      .setStyle(ButtonStyle.Primary);

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(button);

    await interaction.reply({
      content: `<@&${ROLE_IDS.EARLY_ACCESS}>, <@&${ROLE_IDS.PUBLIC_SERVICES}>, <@&${ROLE_IDS.STAFF_TEAM}>, <@&${ROLE_IDS.SERVER_BOOSTER}>`,
      embeds: [embed],
      components: [row as any],
      allowedMentions: { roles: [ROLE_IDS.EARLY_ACCESS, ROLE_IDS.PUBLIC_SERVICES, ROLE_IDS.STAFF_TEAM, ROLE_IDS.SERVER_BOOSTER] },
    });

    await storage.updateSession(session.id, { status: "early_access", sessionLink: link });
  }

  private async handleRelease(interaction: ChatInputCommandInteraction) {
    const frpSpeed = interaction.options.getString("frp_speed", true);
    const peacetimeStatus = interaction.options.getString("peacetime", true);
    const speedLimit = interaction.options.getString("speed_limit", true);
    const houseClaiming = interaction.options.getString("house_claiming", true);
    const link = interaction.options.getString("link", true);

    const session = await storage.getActiveSession();
    if (!session) {
      await interaction.reply({
        content: "No active session found. Please run /startup first.",
        ephemeral: true,
      });
      return;
    }

    const embed = new EmbedBuilder()
      .setColor(EMBED_COLOR)
      .setDescription(
        `${EMOJIS.STARS} **Greenville Roleplay Haze | Session Release** ${EMOJIS.STARS}\n\n` +
        `${EMOJIS.ARROW} ${session.hostName} has released their roleplay session. To participate, just click on the "Roleplay Link" button located below. Upon entry, please find a parking spot and await further instructions from the host. It is important to read the information listed below. Also, ensure you read through <#${CHANNEL_IDS.REGULATIONS}> and ensure you are not driving a vehicle without proper roles.\n\n` +
        `${EMOJIS.DOT} FRP Speeds: ${frpSpeed}\n` +
        `${EMOJIS.DOT} Peacetime Status: ${peacetimeStatus}\n` +
        `${EMOJIS.DOT} Speedlimit Speeds: ${speedLimit}\n` +
        `${EMOJIS.DOT} House Claiming: ${houseClaiming}\n\n` +
        `Having issues with joining? Create a ticket to speak with one of our Staff Members in <#${CHANNEL_IDS.SUPPORT}>`
      )
      .setImage(SESSION_IMAGES.RELEASE);

    const button = new ButtonBuilder()
      .setCustomId(`release_${session.id}`)
      .setLabel("Roleplay Link")
      .setEmoji(EMOJIS.EXTERNAL.match(/<:(\w+):(\d+)>/)?.[2] || "🔗")
      .setStyle(ButtonStyle.Primary);

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(button);

    await interaction.reply({
      content: `<@&${ROLE_IDS.CIVILIAN}>`,
      embeds: [embed],
      components: [row as any],
      allowedMentions: { roles: [ROLE_IDS.CIVILIAN] },
    });

    await storage.updateSession(session.id, {
      status: "released",
      sessionLink: link,
      frpSpeed,
      peacetimeStatus,
      speedLimit,
      houseClaiming,
    });
  }

  private async handleReinvites(interaction: ChatInputCommandInteraction) {
    const link = interaction.options.getString("link", true);

    const session = await storage.getActiveSession();
    if (!session) {
      await interaction.reply({
        content: "No active session found.",
        ephemeral: true,
      });
      return;
    }

    const embed = new EmbedBuilder()
      .setColor(EMBED_COLOR)
      .setDescription(
        `${EMOJIS.LINK} **Greenville Roleplay Haze | Re-Invites** ${EMOJIS.LINK}\n\n` +
        `${EMOJIS.DOT} ${session.hostName} has released Session Re-invites! To participate, just click on the "Re-Invites Link" button located below. Upon entry, please find a parking spot and await further instructions from the host. It is important to read the information listed below. Also, ensure you read through <#${CHANNEL_IDS.REGULATIONS}> and ensure you are not driving a vehicle without proper roles.\n\n` +
        `Also, read the session regulations in the Session Release message. Failure to co-operate with the session regulations will result in a removal from the session and moderation.`
      )
      .setImage(SESSION_IMAGES.REINVITES);

    const button = new ButtonBuilder()
      .setCustomId(`reinvites_${session.id}`)
      .setLabel("Re-Invites Link")
      .setEmoji(EMOJIS.EXTERNAL.match(/<:(\w+):(\d+)>/)?.[2] || "🔗")
      .setStyle(ButtonStyle.Primary);

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(button);

    await interaction.reply({
      content: `<@&${ROLE_IDS.CIVILIAN}>`,
      embeds: [embed],
      components: [row as any],
      allowedMentions: { roles: [ROLE_IDS.CIVILIAN] },
    });

    await storage.updateSession(session.id, { status: "reinvites", sessionLink: link });
  }

  private async handleLinkRegenerated(interaction: ChatInputCommandInteraction) {
    const embed = new EmbedBuilder()
      .setColor(EMBED_COLOR)
      .setDescription(
        `${EMOJIS.LINK} **Greenville Roleplay Haze | Link Regenerated** ${EMOJIS.LINK}\n\n` +
        `The session link has been regenerated, please wait as Re-Invites will occur shortly.`
      );

    await interaction.reply({ embeds: [embed] });
  }

  private async handleLinkOpen(interaction: ChatInputCommandInteraction) {
    const embed = new EmbedBuilder()
      .setColor(EMBED_COLOR)
      .setDescription(
        `${EMOJIS.LINK} **Greenville Roleplay Haze | Link Open** ${EMOJIS.LINK}\n\n` +
        `The session link has been left open to gain playercount. Please ping the host in <#${CHANNEL_IDS.CHECKPOINT_1}> once you have joined, then you may exit spawn.`
      );

    await interaction.reply({ embeds: [embed] });
  }

  private async handleSessionOver(interaction: ChatInputCommandInteraction) {
    const session = await storage.getActiveSession();

    const modal = new ModalBuilder()
      .setCustomId(`session_over_modal${session ? `_${session.id}` : ""}`)
      .setTitle("Session End Details");

    const startTimeInput = new TextInputBuilder()
      .setCustomId("start_time")
      .setLabel("Session Start Time (e.g., 2:00 PM)")
      .setStyle(TextInputStyle.Short)
      .setPlaceholder("2:00 PM")
      .setRequired(true);

    const endTimeInput = new TextInputBuilder()
      .setCustomId("end_time")
      .setLabel("Session End Time (e.g., 5:30 PM)")
      .setStyle(TextInputStyle.Short)
      .setPlaceholder("5:30 PM")
      .setRequired(true);

    const notesInput = new TextInputBuilder()
      .setCustomId("notes")
      .setLabel("Session Notes")
      .setStyle(TextInputStyle.Paragraph)
      .setPlaceholder("Any notes about the session (incidents, highlights, etc.)")
      .setRequired(false);

    const row1 = new ActionRowBuilder<TextInputBuilder>().addComponents(startTimeInput);
    const row2 = new ActionRowBuilder<TextInputBuilder>().addComponents(endTimeInput);
    const row3 = new ActionRowBuilder<TextInputBuilder>().addComponents(notesInput);

    modal.addComponents(row1 as any, row2 as any, row3 as any);

    await interaction.showModal(modal as any);
  }

  private async handleModalSubmit(interaction: ModalSubmitInteraction) {
    if (interaction.customId.startsWith("session_over_modal")) {
      const startTime = interaction.fields.getTextInputValue("start_time");
      const endTime = interaction.fields.getTextInputValue("end_time");
      const notes = interaction.fields.getTextInputValue("notes") || "No notes provided";

      const sessionIdMatch = interaction.customId.match(/session_over_modal_(.+)/);
      const sessionId = sessionIdMatch ? sessionIdMatch[1] : null;

      let session = sessionId ? await storage.getSession(sessionId) : await storage.getActiveSession();

      const hostName = session?.hostName || interaction.user.displayName || interaction.user.username;
      const hostId = session?.hostId || interaction.user.id;

      await storage.logCompletedSession({
        hostId,
        hostName,
        channelId: session?.channelId || interaction.channelId || "unknown",
        startTime,
        endTime,
        notes,
        reactionCount: session?.reactedUsers?.length || 0,
        frpSpeed: session?.frpSpeed || null,
        peacetimeStatus: session?.peacetimeStatus || null,
        speedLimit: session?.speedLimit || null,
        houseClaiming: session?.houseClaiming || null,
        createdAt: session?.createdAt || new Date().toISOString(),
        completedAt: new Date().toISOString(),
      });

      if (session) {
        await storage.updateSession(session.id, { status: "ended" });
      }

      const embed = new EmbedBuilder()
        .setColor(EMBED_COLOR)
        .setDescription(
          `${EMOJIS.STARS} **Greenville Roleplay Haze | Session Over** ${EMOJIS.STARS}\n\n` +
          `The roleplay session has now ended. Thank you for participating!\n\n` +
          `${EMOJIS.DOT} **Host:** ${hostName}\n` +
          `${EMOJIS.DOT} **Start Time:** ${startTime}\n` +
          `${EMOJIS.DOT} **End Time:** ${endTime}\n` +
          `${EMOJIS.DOT} **Notes:** ${notes}`
        )
        .setImage(SESSION_IMAGES.SESSION_OVER);

      await interaction.reply({ embeds: [embed] });
    }
  }

  private async handleSrpHighway(interaction: ChatInputCommandInteraction) {
    const session = await storage.getActiveSession();
    const hostName = session?.hostName || interaction.user.displayName || interaction.user.username;

    const embed = new EmbedBuilder()
      .setColor(EMBED_COLOR)
      .setDescription(
        `${EMOJIS.ROAD} **Greenville Roleplay Haze | Highway Special Roleplay** ${EMOJIS.ROAD}\n\n` +
        `${hostName} has been given permission to do a Highway Special Roleplay! You must abide by the following rules:\n\n` +
        `${EMOJIS.ARROW} FRP Speeds: 100MPH\n` +
        `${EMOJIS.ARROW} Speedlimit: 75MPH\n` +
        `${EMOJIS.ARROW} LEO Status: Online`
      )
      .setImage(SESSION_IMAGES.SRP_HIGHWAY);

    await interaction.reply({
      content: "@here",
      embeds: [embed],
      allowedMentions: { parse: ["everyone"] },
    });
  }

  private async handleSrpDual(interaction: ChatInputCommandInteraction) {
    const overtaking = interaction.options.getString("overtaking", true);
    const frpLimit = interaction.options.getString("frp_limit", true);
    const speedLimit = interaction.options.getString("speed_limit", true);

    const session = await storage.getActiveSession();
    const hostName = session?.hostName || interaction.user.displayName || interaction.user.username;

    const embed = new EmbedBuilder()
      .setColor(EMBED_COLOR)
      .setDescription(
        `${EMOJIS.ROADS2} **Greenville Roleplay Haze | Dual Lane Special Roleplay** ${EMOJIS.ROADS2}\n\n` +
        `${hostName} has been given permission to do a Dual Lane Special Roleplay! You must abide by the following rules:\n\n` +
        `${EMOJIS.ARROW} Overtaking: ${overtaking}\n` +
        `${EMOJIS.ARROW} FRP Limit: ${frpLimit}\n` +
        `${EMOJIS.ARROW} Speedlimit: ${speedLimit}`
      )
      .setImage(SESSION_IMAGES.SRP_DUALLANE);

    await interaction.reply({
      content: "@here",
      embeds: [embed],
      allowedMentions: { parse: ["everyone"] },
    });
  }

  private async handleSrpConstruction(interaction: ChatInputCommandInteraction) {
    const zoneFrp = interaction.options.getString("zone_frp", true);
    const zoneSpeedLimit = interaction.options.getString("zone_speed_limit", true);

    const session = await storage.getActiveSession();
    const hostName = session?.hostName || interaction.user.displayName || interaction.user.username;

    const embed = new EmbedBuilder()
      .setColor(EMBED_COLOR)
      .setDescription(
        `${EMOJIS.CONSTRUCTION} **Greenville Roleplay Haze | Construction Special Roleplay** ${EMOJIS.CONSTRUCTION}\n\n` +
        `${hostName} has been given permission to do a Construction Special Roleplay! You must abide by the following rules:\n\n` +
        `${EMOJIS.ARROW} Construction Zone FRP: ${zoneFrp}\n` +
        `${EMOJIS.ARROW} Construction Zone Speedlimit: ${zoneSpeedLimit}`
      )
      .setImage(SESSION_IMAGES.SRP_CONSTRUCTION);

    await interaction.reply({
      content: "@here",
      embeds: [embed],
      allowedMentions: { parse: ["everyone"] },
    });
  }

  private async handleSrpCarmeet(interaction: ChatInputCommandInteraction) {
    const location = interaction.options.getString("location", true);

    const session = await storage.getActiveSession();
    const hostName = session?.hostName || interaction.user.displayName || interaction.user.username;

    const embed = new EmbedBuilder()
      .setColor(EMBED_COLOR)
      .setDescription(
        `${EMOJIS.CAR} **Greenville Roleplay Haze | Carmeet Special Roleplay** ${EMOJIS.CAR}\n\n` +
        `${hostName} has been given permission to do a Carmeet Special Roleplay! You must abide by the following rules:\n\n` +
        `You all must make your way to ${location}\n\n` +
        `All Cars are drivable! Please do not beg the host to rate the cars, they will choose who rates.`
      )
      .setImage(SESSION_IMAGES.SRP_CARMEET);

    await interaction.reply({
      content: "@here",
      embeds: [embed],
      allowedMentions: { parse: ["everyone"] },
    });
  }

  private async handleSrpSchool(interaction: ChatInputCommandInteraction) {
    const lesson1 = interaction.options.getString("lesson1", true);
    const lesson2 = interaction.options.getString("lesson2", true);
    const lesson3 = interaction.options.getString("lesson3", true);

    const session = await storage.getActiveSession();
    const hostName = session?.hostName || interaction.user.displayName || interaction.user.username;

    const embed = new EmbedBuilder()
      .setColor(EMBED_COLOR)
      .setDescription(
        `${EMOJIS.STARS} **Greenville Roleplay Haze | School Special Roleplay** ${EMOJIS.STARS}\n\n` +
        `${hostName} has been given permission to do a School Special Roleplay! You must abide by the following rules:\n\n` +
        `Only teachers can drive to school. Students ride the bus to school. Failure to follow these rules may result in a removal from the session.\n\n` +
        `${EMOJIS.ARROW} School day Timetable:\n` +
        `${EMOJIS.REPLY} 8:45AM-10:00AM: ${lesson1}\n` +
        `${EMOJIS.REPLY} 10:15AM-11:30AM: ${lesson2}\n` +
        `${EMOJIS.REPLY} 11:30AM-12:15PM: Break Time\n` +
        `${EMOJIS.REPLY} 12:15PM-13:30PM: ${lesson3}`
      )
      .setImage(SESSION_IMAGES.SRP_SCHOOL);

    await interaction.reply({
      content: "@here",
      embeds: [embed],
      allowedMentions: { parse: ["everyone"] },
    });
  }

  private async handleRegister(interaction: ChatInputCommandInteraction) {
    const vehicleName = interaction.options.getString("vehicle_name", true);
    const vehiclePlate = interaction.options.getString("vehicle_plate", true);

    await storage.registerVehicle({
      odiscordUserId: interaction.user.id,
      vehicleName,
      vehiclePlate,
    });

    const embed = new EmbedBuilder()
      .setColor(EMBED_COLOR)
      .setDescription(
        `${EMOJIS.CAR} **Vehicle Registered Successfully** ${EMOJIS.CAR}\n\n` +
        `${EMOJIS.TICK} Vehicle: ${vehicleName}\n` +
        `${EMOJIS.TICK} Plate: ${vehiclePlate}`
      );

    await interaction.reply({ embeds: [embed], ephemeral: true });
  }

  private async handleButtonInteraction(interaction: ButtonInteraction) {
    const customId = interaction.customId;
    const session = await storage.getActiveSession();

    if (!session || !session.sessionLink) {
      await interaction.reply({
        content: "This session is no longer active.",
        ephemeral: true,
      });
      return;
    }

    const member = interaction.member;
    if (!member) {
      await interaction.reply({
        content: "Could not verify your roles.",
        ephemeral: true,
      });
      return;
    }

    const memberRoles = Array.isArray(member.roles) 
      ? member.roles 
      : Array.from(member.roles.cache.keys());

    if (customId.startsWith("early_access")) {
      const allowedRoles = [ROLE_IDS.EARLY_ACCESS, ROLE_IDS.PUBLIC_SERVICES, ROLE_IDS.STAFF_TEAM, ROLE_IDS.SERVER_BOOSTER];
      const hasRole = allowedRoles.some(role => memberRoles.includes(role));

      if (!hasRole) {
        await interaction.reply({
          content: "You do not have the correct roles to interact with this button!",
          ephemeral: true,
        });
        return;
      }

      await interaction.reply({
        content: `Click [Here](${session.sessionLink}) for access to the session.`,
        ephemeral: true,
      });
    } else if (customId.startsWith("release") || customId.startsWith("reinvites")) {
      const hasRole = memberRoles.includes(ROLE_IDS.CIVILIAN);

      if (!hasRole) {
        await interaction.reply({
          content: "You do not have the correct roles to interact with this button!",
          ephemeral: true,
        });
        return;
      }

      const hasReacted = await storage.hasUserReacted(session.id, interaction.user.id);
      if (!hasReacted) {
        await interaction.reply({
          content: "You need to react to the startup message before you are allowed to join.",
          ephemeral: true,
        });
        return;
      }

      await interaction.reply({
        content: `Click [Here](${session.sessionLink}) for access to the session.`,
        ephemeral: true,
      });
    }
  }

  private async handleSelectMenuInteraction(interaction: StringSelectMenuInteraction) {
    await interaction.deferUpdate();
  }

  async registerCommands(guildId?: string) {
    if (!CLIENT_ID || !BOT_TOKEN) {
      console.error("Missing DISCORD_CLIENT_ID or DISCORD_BOT_TOKEN");
      return;
    }

    const commands = [
      new SlashCommandBuilder()
        .setName("startup")
        .setDescription("Start a new roleplay session")
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

      new SlashCommandBuilder()
        .setName("setup")
        .setDescription("Announce session setup in progress")
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

      new SlashCommandBuilder()
        .setName("early-access")
        .setDescription("Release early access link")
        .addStringOption((option) =>
          option.setName("link").setDescription("The session link").setRequired(true)
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

      new SlashCommandBuilder()
        .setName("release")
        .setDescription("Release the session to everyone")
        .addStringOption((option) =>
          option
            .setName("frp_speed")
            .setDescription("FRP Speed limit")
            .setRequired(true)
            .addChoices(
              { name: "65MPH", value: "65MPH" },
              { name: "80MPH", value: "80MPH" },
              { name: "90MPH", value: "90MPH" },
              { name: "100MPH", value: "100MPH" }
            )
        )
        .addStringOption((option) =>
          option
            .setName("peacetime")
            .setDescription("Peacetime status")
            .setRequired(true)
            .addChoices(
              { name: "Strict", value: "Strict" },
              { name: "Normal", value: "Normal" },
              { name: "Off", value: "Off" }
            )
        )
        .addStringOption((option) =>
          option
            .setName("speed_limit")
            .setDescription("Speed limit")
            .setRequired(true)
            .addChoices(
              { name: "On signs", value: "On signs" },
              { name: "65MPH", value: "65MPH" },
              { name: "70MPH", value: "70MPH" },
              { name: "80MPH", value: "80MPH" }
            )
        )
        .addStringOption((option) =>
          option
            .setName("house_claiming")
            .setDescription("House claiming status")
            .setRequired(true)
            .addChoices(
              { name: "On", value: "On" },
              { name: "Off", value: "Off" }
            )
        )
        .addStringOption((option) =>
          option.setName("link").setDescription("The session link").setRequired(true)
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

      new SlashCommandBuilder()
        .setName("re-invites")
        .setDescription("Send re-invite link")
        .addStringOption((option) =>
          option.setName("link").setDescription("The session link").setRequired(true)
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

      new SlashCommandBuilder()
        .setName("link-regenerated")
        .setDescription("Announce link regeneration")
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

      new SlashCommandBuilder()
        .setName("link-open")
        .setDescription("Announce link is open for joining")
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

      new SlashCommandBuilder()
        .setName("session-over")
        .setDescription("End the current session with details")
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

      new SlashCommandBuilder()
        .setName("srp-highway")
        .setDescription("Announce Highway Special Roleplay")
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

      new SlashCommandBuilder()
        .setName("srp-dual")
        .setDescription("Announce Dual Lane Special Roleplay")
        .addStringOption((option) =>
          option
            .setName("overtaking")
            .setDescription("Overtaking status")
            .setRequired(true)
            .addChoices(
              { name: "On", value: "On" },
              { name: "Off", value: "Off" }
            )
        )
        .addStringOption((option) =>
          option
            .setName("frp_limit")
            .setDescription("FRP limit")
            .setRequired(true)
            .addChoices(
              { name: "65MPH", value: "65MPH" },
              { name: "70MPH", value: "70MPH" },
              { name: "80MPH", value: "80MPH" },
              { name: "90MPH", value: "90MPH" }
            )
        )
        .addStringOption((option) =>
          option
            .setName("speed_limit")
            .setDescription("Speed limit")
            .setRequired(true)
            .addChoices(
              { name: "55MPH", value: "55MPH" },
              { name: "60MPH", value: "60MPH" },
              { name: "70MPH", value: "70MPH" },
              { name: "75MPH", value: "75MPH" }
            )
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

      new SlashCommandBuilder()
        .setName("srp-construction")
        .setDescription("Announce Construction Special Roleplay")
        .addStringOption((option) =>
          option
            .setName("zone_frp")
            .setDescription("Construction zone FRP")
            .setRequired(true)
            .addChoices(
              { name: "25MPH", value: "25MPH" },
              { name: "30MPH", value: "30MPH" },
              { name: "35MPH", value: "35MPH" }
            )
        )
        .addStringOption((option) =>
          option
            .setName("zone_speed_limit")
            .setDescription("Construction zone speed limit")
            .setRequired(true)
            .addChoices(
              { name: "15MPH", value: "15MPH" },
              { name: "20MPH", value: "20MPH" },
              { name: "25MPH", value: "25MPH" }
            )
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

      new SlashCommandBuilder()
        .setName("srp-carmeet")
        .setDescription("Announce Carmeet Special Roleplay")
        .addStringOption((option) =>
          option.setName("location").setDescription("Carmeet location").setRequired(true)
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

      new SlashCommandBuilder()
        .setName("srp-school")
        .setDescription("Announce School Special Roleplay")
        .addStringOption((option) =>
          option.setName("lesson1").setDescription("First lesson").setRequired(true)
        )
        .addStringOption((option) =>
          option.setName("lesson2").setDescription("Second lesson").setRequired(true)
        )
        .addStringOption((option) =>
          option.setName("lesson3").setDescription("Third lesson").setRequired(true)
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

      new SlashCommandBuilder()
        .setName("register")
        .setDescription("Register a vehicle")
        .addStringOption((option) =>
          option.setName("vehicle_name").setDescription("Name of the vehicle").setRequired(true)
        )
        .addStringOption((option) =>
          option.setName("vehicle_plate").setDescription("License plate").setRequired(true)
        ),
    ];

    try {
      this.rest.setToken(BOT_TOKEN);
      console.log("Started refreshing application (/) commands.");

      if (guildId) {
        await this.rest.put(Routes.applicationGuildCommands(CLIENT_ID, guildId), {
          body: commands.map((c) => c.toJSON()),
        });
        console.log(`Successfully registered commands for guild ${guildId}`);
      } else {
        await this.rest.put(Routes.applicationCommands(CLIENT_ID), {
          body: commands.map((c) => c.toJSON()),
        });
        console.log("Successfully registered global commands.");
      }
    } catch (error) {
      console.error("Error registering commands:", error);
    }
  }

  async start() {
    if (!BOT_TOKEN) {
      console.error("DISCORD_BOT_TOKEN not set. Bot will not start.");
      return;
    }

    try {
      await this.client.login(BOT_TOKEN);
      console.log("Discord bot started successfully");
    } catch (error) {
      console.error("Failed to start Discord bot:", error);
    }
  }

  getStatus() {
    return {
      isReady: this.isReady,
      username: this.client.user?.username,
      guilds: this.client.guilds.cache.size,
    };
  }
}

export const discordBot = new DiscordBot();

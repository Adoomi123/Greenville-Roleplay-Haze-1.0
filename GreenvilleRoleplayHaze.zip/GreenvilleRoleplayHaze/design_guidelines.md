# Greenville Roleplay Haze Discord Bot - Design Guidelines

## Design Approach

**Platform-Specific Design**: Discord bot interface using Discord's embed system, buttons, and slash commands. All visual design must work within Discord's component constraints.

## Core Design Specifications

### Color Palette
- **Primary Embed Color**: `#5c99bb` (Teal blue - used for all embed sidebars)
- **Discord Dark Theme**: Design assumes dark mode Discord interface
- **Text**: High contrast white text on dark backgrounds

### Typography & Formatting
- **Font**: Discord's default system fonts (Whitney/Ginto)
- **Emoji Usage**: Custom server emojis for visual hierarchy and branding
  - Roads/Car icons for session types
  - Arrow/Dot icons for list items
  - Link/External icons for buttons
  - Stars/Tick icons for status indicators
- **Formatting Style**: 
  - Bold (`**text**`) for section headers and emphasis
  - Inline code for specific values
  - Clear visual hierarchy with emoji prefixes

### Embed Structure Pattern

**Consistent Layout Across All Commands**:
1. **Header**: Emoji + Bold Title + Emoji (symmetrical)
2. **Main Content**: Arrow emoji (`:Arrow:`) for primary instructions
3. **Sub-items**: Dot emoji (`:dot:`) for secondary details
4. **Footer**: Informational text with channel links when relevant

### Component Design

**Interactive Buttons**:
- **Text Format**: `<:external:emoji> Button Label`
- **Behavior**: Role-gated access with custom error messages
- **Link Insertion**: Host provides custom URL per session
- **States**:
  - Authorized role: Shows link with "Click [Here](url)" format
  - Unauthorized: "You do not have the correct roles to interact with this button!"
  - Missing reaction: "You need to react to the startup message before you are allowed to join"

**Role Mentions**:
- Placed outside embeds for proper Discord notifications
- Targeted per command type (@Civilian, @Early Access, @here, etc.)

### Images

**Command-Specific Visuals**:
Each major command includes a unique image attachment:
- Session Startup: Game preview image
- Session Setup: Setup preparation visual  
- Early Access: Exclusive access imagery
- Session Release: Main session visual
- Re-Invites: Re-entry visual
- SRP variants: Themed images per roleplay type (Highway, Construction, School, Car Meet, Dual Lane)

**Placement**: Images appear below embed content, before buttons

### Information Hierarchy

**Critical Information Priority**:
1. Session status/type (header)
2. Host name (auto-filled variable)
3. Action required from users
4. Rules and requirements
5. Links to regulations/support channels

**Input Fields** (Host Configuration):
- Dropdown selectors for standardized options (FRP speeds, Peacetime status, Speed limits, House claiming toggles)
- Text input for custom values (links, location names)
- All inputs contextual to command type

### Interaction Patterns

**Progressive Disclosure**:
1. `/startup` - Announcement + reaction requirement (6+ reactions threshold)
2. `/setup` - 10-minute preparation notice
3. `/early-access` - Role-gated early entry
4. `/release` - Public access with session configuration display
5. `/re-invites` - Session re-entry

**Reaction Tracking**: 
- Startup message requires user reaction
- Reaction status gates access to session link buttons
- Prevents unauthorized entry

### Special Roleplay Variants

**Consistent SRP Format**:
- Unique icon pairing for each type
- @here mention for urgency
- Host name acknowledgment
- Rule specifications with clear values
- Dropdown/input fields for host customization

### Accessibility & Usability

- **Clear Channel References**: Full channel links with IDs for easy navigation
- **Role Clarity**: Explicit role requirements for each action
- **Error Prevention**: Validation messages before actions (reaction checks, role verification)
- **Mobile Friendly**: All embeds readable on Discord mobile app
- **Consistent Formatting**: Predictable structure across all commands for quick scanning

### Branding Elements

- **Bot Name Display**: "Greenville Roleplay Haze" in all embed titles
- **Icon Usage**: Road/car emojis reinforce roleplay theme
- **Color Consistency**: #5c99bb throughout creates brand recognition
- **Professional Tone**: Clear, authoritative language for session management
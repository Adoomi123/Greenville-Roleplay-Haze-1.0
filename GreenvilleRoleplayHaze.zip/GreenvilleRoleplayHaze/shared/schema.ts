import { z } from "zod";

export const sessionStateSchema = z.object({
  id: z.string(),
  startupMessageId: z.string().nullable(),
  channelId: z.string(),
  hostId: z.string(),
  hostName: z.string(),
  status: z.enum(["startup", "setup", "early_access", "released", "reinvites", "ended"]),
  sessionLink: z.string().nullable(),
  frpSpeed: z.string().nullable(),
  peacetimeStatus: z.string().nullable(),
  speedLimit: z.string().nullable(),
  houseClaiming: z.string().nullable(),
  reactedUsers: z.array(z.string()),
  createdAt: z.string(),
});

export type SessionState = z.infer<typeof sessionStateSchema>;
export type InsertSessionState = Omit<SessionState, "id" | "createdAt">;

export const completedSessionSchema = z.object({
  id: z.string(),
  hostId: z.string(),
  hostName: z.string(),
  channelId: z.string(),
  startTime: z.string(),
  endTime: z.string(),
  notes: z.string(),
  reactionCount: z.number(),
  frpSpeed: z.string().nullable(),
  peacetimeStatus: z.string().nullable(),
  speedLimit: z.string().nullable(),
  houseClaiming: z.string().nullable(),
  createdAt: z.string(),
  completedAt: z.string(),
});

export type CompletedSession = z.infer<typeof completedSessionSchema>;
export type InsertCompletedSession = Omit<CompletedSession, "id">;

export const hostSummarySchema = z.object({
  hostId: z.string(),
  hostName: z.string(),
  totalSessions: z.number(),
  lastSessionDate: z.string().nullable(),
  sessions: z.array(completedSessionSchema),
});

export type HostSummary = z.infer<typeof hostSummarySchema>;

export const vehicleRegistrationSchema = z.object({
  id: z.string(),
  odiscordUserId: z.string(),
  vehicleName: z.string(),
  vehiclePlate: z.string(),
  registeredAt: z.string(),
});

export type VehicleRegistration = z.infer<typeof vehicleRegistrationSchema>;

export const users = {
  id: "",
  username: "",
  password: "",
};

export type User = typeof users;
export type InsertUser = Omit<User, "id">;

export const ROLE_IDS = {
  EARLY_ACCESS: "1428832378041794570",
  PUBLIC_SERVICES: "1407661660545745101",
  STAFF_TEAM: "1336441366120501421",
  SERVER_BOOSTER: "1412881149910450407",
  CIVILIAN: "1428793843184046151",
};

export const CHANNEL_IDS = {
  REGULATIONS: "1309873204004913193",
  BOT_COMMANDS: "1407653107202261102",
  SUPPORT: "1407671357474476072",
  CHECKPOINT_1: "1407661105437736991",
};

export const EMOJIS = {
  ANNOUNCE: "<:announce:1409302798125760552>",
  ARROW: "<:arrow:1444058433224577187>",
  CAR: "<:car:1444057127646924891>",
  DOT: "<:dot:1409590638176899144>",
  LINK: "<:link:1409590632573308950>",
  JUDGE: "<:judge:1409590635815764109>",
  EXTERNAL: "<:external:1409590629406867598>",
  PARTY: "<:party:1409590616349872188>",
  REPLY: "<:reply:1444056876101664778>",
  STARS: "<:stars:1409590624172249319>",
  STAR: "<:star:1409590602995073065>",
  STAFF: "<:staff:1409590597852987452>",
  ROADS2: "<:roads2:1409590608737341621>",
  ROAD: "<:road:1409590610901340272>",
  TICK: "<:tick:1444058348399100127>",
  TICKET: "<:ticket:1409590606140932176>",
  CONSTRUCTION: "<:Construction:1439195457254457455>",
};

export const EMBED_COLOR = 0x5c99bb;

export const SESSION_IMAGES = {
  STARTUP: "https://media.discordapp.net/attachments/1445312584873148579/1445314049075052574/IMG_9474.png?ex=69328819&is=69313699&hm=880391e18b4311387b5e0d16d9c948ace797e064aae0044512d8eb3243032f8b&=&format=webp&quality=lossless",
  SETUP: "https://media.discordapp.net/attachments/1445312584873148579/1445314049578504242/IMG_9475.png?ex=6932881a&is=6931369a&hm=1f627d8d1ab145cd5b3628fa14eb52aab802588d6ce1fbe7e5cd6b987b2f4ea3&=&format=webp&quality=lossless",
  RELEASE: "https://media.discordapp.net/attachments/1445312584873148579/1445314050325217282/IMG_9477.png?ex=6932881a&is=6931369a&hm=94a6ec50a63a3af17d0c04bf7437bdad3a81e7558cc8a13c6cd34a421301ea6d&=&format=webp&quality=lossless",
  EARLY_ACCESS: "https://media.discordapp.net/attachments/1445312584873148579/1445314049909985311/IMG_9476.png?ex=6932881a&is=6931369a&hm=c7bb26a2adf5a5892408b081a3e983c765e4d2df80246d0edd4e18266870cb87&=&format=webp&quality=lossless",
  REINVITES: "https://media.discordapp.net/attachments/1445312584873148579/1445314050647920670/IMG_9478.png?ex=6932881a&is=6931369a&hm=73c2c7c44172b1a8d4ab2434548885d0858c5f74d8a5787df7c416c580af56f7&=&format=webp&quality=lossless",
  SESSION_OVER: "https://media.discordapp.net/attachments/1445312584873148579/1445314051432386581/IMG_9479.png?ex=6932881a&is=6931369a&hm=d39c08c90602ecad71b76a916f4aee0b09f14aa1a0950258335e297edb10cb06&=&format=webp&quality=lossless",
  SRP_CARMEET: "https://media.discordapp.net/attachments/1445316183740911737/1445829571965620346/IMG_9625.png?ex=69326df8&is=69311c78&hm=8992ac61153df42485ffbfd6c2bf37b7bfd2da1d3a9223f2c3e575decf98c3bd&=&format=webp&quality=lossless",
  SRP_CONSTRUCTION: "https://media.discordapp.net/attachments/1445316183740911737/1445829572464607362/IMG_9627.png?ex=69326df8&is=69311c78&hm=e6cc9f970023736dd05f297edeab1d41ada95111237e0ce102812f24f067883d&=&format=webp&quality=lossless",
  SRP_SCHOOL: "https://media.discordapp.net/attachments/1445316183740911737/1445829573060329592/IMG_9628.png?ex=69326df8&is=69311c78&hm=e081e7ad6791369dc69a6fdbb546fedab80f3e458b382b6a51e6597344e35fcf&=&format=webp&quality=lossless",
  SRP_DUALLANE: "https://media.discordapp.net/attachments/1445316183740911737/1445829573530095678/IMG_9629.png?ex=69326df8&is=69311c78&hm=19cff5dff56a67caa31ffb80504ebe1a9fd5f1150a3a221a333ad8f2c2903155&=&format=webp&quality=lossless",
  SRP_HIGHWAY: "https://media.discordapp.net/attachments/1445316183740911737/1445829573974556847/IMG_9630.png?ex=69326df8&is=69311c78&hm=5ab2716de44d7be78bb40040c6008b662a1b4fb701a4ec512d2973069768dd24&=&format=webp&quality=lossless",
};

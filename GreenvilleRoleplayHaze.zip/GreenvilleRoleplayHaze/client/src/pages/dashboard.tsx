import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useState } from "react";
import { 
  Activity, 
  Bot, 
  Users, 
  PlayCircle, 
  Settings, 
  Radio,
  CheckCircle,
  XCircle,
  Clock,
  Car,
  Zap,
  Server,
  Search,
  History,
  UserCircle,
  FileText,
  Calendar
} from "lucide-react";

interface BotStatus {
  isReady: boolean;
  username: string | null;
  guilds: number;
}

interface SessionState {
  id: string;
  startupMessageId: string | null;
  channelId: string;
  hostId: string;
  hostName: string;
  status: "startup" | "setup" | "early_access" | "released" | "reinvites" | "ended";
  sessionLink: string | null;
  frpSpeed: string | null;
  peacetimeStatus: string | null;
  speedLimit: string | null;
  houseClaiming: string | null;
  reactedUsers: string[];
  createdAt: string;
}

interface CompletedSession {
  id: string;
  hostId: string;
  hostName: string;
  channelId: string;
  startTime: string;
  endTime: string;
  notes: string;
  reactionCount: number;
  frpSpeed: string | null;
  peacetimeStatus: string | null;
  speedLimit: string | null;
  houseClaiming: string | null;
  createdAt: string;
  completedAt: string;
}

interface HostSummary {
  hostId: string;
  hostName: string;
  totalSessions: number;
  lastSessionDate: string | null;
  sessions: CompletedSession[];
}

function getStatusColor(status: string): string {
  switch (status) {
    case "startup":
      return "bg-yellow-500/10 text-yellow-500 border-yellow-500/20";
    case "setup":
      return "bg-blue-500/10 text-blue-500 border-blue-500/20";
    case "early_access":
      return "bg-purple-500/10 text-purple-500 border-purple-500/20";
    case "released":
      return "bg-green-500/10 text-green-500 border-green-500/20";
    case "reinvites":
      return "bg-cyan-500/10 text-cyan-500 border-cyan-500/20";
    case "ended":
      return "bg-muted text-muted-foreground border-muted";
    default:
      return "bg-muted text-muted-foreground border-muted";
  }
}

function getStatusLabel(status: string): string {
  switch (status) {
    case "startup":
      return "Starting Up";
    case "setup":
      return "Setting Up";
    case "early_access":
      return "Early Access";
    case "released":
      return "Released";
    case "reinvites":
      return "Re-Invites";
    case "ended":
      return "Ended";
    default:
      return status;
  }
}

export default function Dashboard() {
  const { toast } = useToast();
  const [guildId, setGuildId] = useState("");
  const [hostSearch, setHostSearch] = useState("");
  const [selectedHost, setSelectedHost] = useState<HostSummary | null>(null);

  const { data: botStatus, isLoading: statusLoading } = useQuery<BotStatus>({
    queryKey: ["/api/bot/status"],
    refetchInterval: 5000,
  });

  const { data: activeSession, isLoading: sessionLoading } = useQuery<SessionState | null>({
    queryKey: ["/api/sessions/active"],
    refetchInterval: 3000,
  });

  const { data: allSessions } = useQuery<SessionState[]>({
    queryKey: ["/api/sessions"],
    refetchInterval: 10000,
  });

  const { data: completedSessions } = useQuery<CompletedSession[]>({
    queryKey: ["/api/sessions/completed"],
    refetchInterval: 5000,
  });

  const { data: hosts } = useQuery<HostSummary[]>({
    queryKey: ["/api/hosts/search", hostSearch],
    queryFn: async () => {
      const response = await fetch(`/api/hosts/search?q=${encodeURIComponent(hostSearch)}`);
      if (!response.ok) throw new Error("Failed to fetch hosts");
      return response.json();
    },
  });

  const registerMutation = useMutation({
    mutationFn: async (guildId: string) => {
      return apiRequest("POST", "/api/bot/register-commands", { guildId: guildId || undefined });
    },
    onSuccess: () => {
      toast({
        title: "Commands Registered",
        description: "Slash commands have been registered successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Registration Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleRegisterCommands = () => {
    registerMutation.mutate(guildId);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center">
                <Bot className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h1 className="text-xl font-semibold" data-testid="text-title">Greenville Roleplay Haze</h1>
                <p className="text-sm text-muted-foreground">Discord Bot Dashboard</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {botStatus?.isReady ? (
                <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20 gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                  Online
                </Badge>
              ) : (
                <Badge variant="outline" className="bg-red-500/10 text-red-500 border-red-500/20 gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-red-500" />
                  Offline
                </Badge>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card data-testid="card-status">
            <CardContent className="p-4">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Bot Status</p>
                  <p className="text-2xl font-semibold" data-testid="text-bot-status">
                    {statusLoading ? "Loading..." : botStatus?.isReady ? "Online" : "Offline"}
                  </p>
                </div>
                <div className={`w-12 h-12 rounded-md flex items-center justify-center ${botStatus?.isReady ? 'bg-green-500/10' : 'bg-red-500/10'}`}>
                  {botStatus?.isReady ? (
                    <CheckCircle className="w-6 h-6 text-green-500" />
                  ) : (
                    <XCircle className="w-6 h-6 text-red-500" />
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card data-testid="card-guilds">
            <CardContent className="p-4">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Connected Servers</p>
                  <p className="text-2xl font-semibold" data-testid="text-guilds">
                    {statusLoading ? "..." : botStatus?.guilds || 0}
                  </p>
                </div>
                <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center">
                  <Server className="w-6 h-6 text-primary" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card data-testid="card-session-status">
            <CardContent className="p-4">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Session Status</p>
                  <p className="text-2xl font-semibold" data-testid="text-session-status">
                    {sessionLoading ? "..." : activeSession ? getStatusLabel(activeSession.status) : "No Session"}
                  </p>
                </div>
                <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center">
                  <Radio className="w-6 h-6 text-primary" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card data-testid="card-total-sessions">
            <CardContent className="p-4">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Total Sessions</p>
                  <p className="text-2xl font-semibold" data-testid="text-total-sessions">
                    {completedSessions?.length || 0}
                  </p>
                </div>
                <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center">
                  <History className="w-6 h-6 text-primary" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList data-testid="tabs-main">
            <TabsTrigger value="overview" data-testid="tab-overview">Overview</TabsTrigger>
            <TabsTrigger value="hosts" data-testid="tab-hosts">Hosts</TabsTrigger>
            <TabsTrigger value="logs" data-testid="tab-logs">Session Logs</TabsTrigger>
            <TabsTrigger value="settings" data-testid="tab-settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-6">
                {activeSession && (
                  <Card data-testid="card-active-session">
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between gap-4 flex-wrap">
                        <div>
                          <CardTitle className="flex items-center gap-2">
                            <PlayCircle className="w-5 h-5 text-primary" />
                            Active Session
                          </CardTitle>
                          <CardDescription>Current roleplay session details</CardDescription>
                        </div>
                        <Badge variant="outline" className={getStatusColor(activeSession.status)}>
                          {getStatusLabel(activeSession.status)}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <p className="text-sm text-muted-foreground">Host</p>
                          <p className="font-medium" data-testid="text-host">{activeSession.hostName}</p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-sm text-muted-foreground">Started</p>
                          <p className="font-medium" data-testid="text-started">
                            {new Date(activeSession.createdAt).toLocaleTimeString()}
                          </p>
                        </div>
                      </div>

                      {activeSession.frpSpeed && (
                        <>
                          <Separator />
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                            <div className="space-y-1">
                              <p className="text-sm text-muted-foreground flex items-center gap-1">
                                <Zap className="w-3 h-3" /> FRP Speed
                              </p>
                              <p className="font-medium">{activeSession.frpSpeed}</p>
                            </div>
                            <div className="space-y-1">
                              <p className="text-sm text-muted-foreground">Peacetime</p>
                              <p className="font-medium">{activeSession.peacetimeStatus}</p>
                            </div>
                            <div className="space-y-1">
                              <p className="text-sm text-muted-foreground flex items-center gap-1">
                                <Car className="w-3 h-3" /> Speed Limit
                              </p>
                              <p className="font-medium">{activeSession.speedLimit}</p>
                            </div>
                            <div className="space-y-1">
                              <p className="text-sm text-muted-foreground">House Claiming</p>
                              <p className="font-medium">{activeSession.houseClaiming}</p>
                            </div>
                          </div>
                        </>
                      )}

                      <Separator />
                      <div className="flex items-center justify-between gap-4 flex-wrap">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Users className="w-4 h-4" />
                          <span>{activeSession.reactedUsers.length} users reacted to startup</span>
                        </div>
                        {activeSession.reactedUsers.length >= 6 ? (
                          <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                            Ready to setup
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="bg-yellow-500/10 text-yellow-500 border-yellow-500/20">
                            Need {6 - activeSession.reactedUsers.length} more reactions
                          </Badge>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                )}

                <Card data-testid="card-available-commands">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Activity className="w-5 h-5 text-primary" />
                      Available Commands
                    </CardTitle>
                    <CardDescription>All slash commands available in the bot</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {[
                        { name: "/startup", desc: "Start a new session" },
                        { name: "/setup", desc: "Session setup announcement" },
                        { name: "/early-access", desc: "Release early access" },
                        { name: "/release", desc: "Release session to public" },
                        { name: "/re-invites", desc: "Send re-invite links" },
                        { name: "/link-regenerated", desc: "Link regen notification" },
                        { name: "/link-open", desc: "Open link notification" },
                        { name: "/session-over", desc: "End session with details" },
                        { name: "/srp-highway", desc: "Highway SRP" },
                        { name: "/srp-dual", desc: "Dual Lane SRP" },
                        { name: "/srp-construction", desc: "Construction SRP" },
                        { name: "/srp-carmeet", desc: "Car Meet SRP" },
                        { name: "/srp-school", desc: "School SRP" },
                        { name: "/register", desc: "Register a vehicle" },
                      ].map((cmd) => (
                        <div key={cmd.name} className="flex items-center justify-between gap-2 p-2 rounded-md bg-muted/50">
                          <code className="text-sm font-mono text-primary">{cmd.name}</code>
                          <span className="text-xs text-muted-foreground">{cmd.desc}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-6">
                <Card data-testid="card-recent-sessions">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Clock className="w-5 h-5 text-primary" />
                      Recent Sessions
                    </CardTitle>
                    <CardDescription>Latest completed sessions</CardDescription>
                  </CardHeader>
                  <CardContent className="p-0">
                    <ScrollArea className="h-[400px]">
                      {completedSessions && completedSessions.length > 0 ? (
                        <div className="divide-y">
                          {completedSessions.slice(0, 10).map((session) => (
                            <div key={session.id} className="p-4">
                              <div className="flex items-center justify-between gap-2 mb-2">
                                <span className="font-medium text-sm">{session.hostName}</span>
                                <Badge variant="outline" className="text-xs">
                                  {session.startTime} - {session.endTime}
                                </Badge>
                              </div>
                              <p className="text-xs text-muted-foreground">
                                {new Date(session.completedAt).toLocaleDateString()}
                              </p>
                              {session.notes && session.notes !== "No notes provided" && (
                                <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                                  {session.notes}
                                </p>
                              )}
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="p-8 text-center text-muted-foreground">
                          <Clock className="w-8 h-8 mx-auto mb-2 opacity-50" />
                          <p className="text-sm">No sessions logged yet</p>
                        </div>
                      )}
                    </ScrollArea>
                  </CardContent>
                </Card>

                <Card data-testid="card-bot-info">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Bot className="w-5 h-5 text-primary" />
                      Bot Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-sm text-muted-foreground">Username</span>
                      <span className="text-sm font-medium" data-testid="text-bot-username">
                        {botStatus?.username || "Not connected"}
                      </span>
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-sm text-muted-foreground">Servers</span>
                      <span className="text-sm font-medium">{botStatus?.guilds || 0}</span>
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-sm text-muted-foreground">Status</span>
                      <Badge variant={botStatus?.isReady ? "default" : "secondary"} className="text-xs">
                        {botStatus?.isReady ? "Connected" : "Disconnected"}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="hosts" className="space-y-6">
            <Card data-testid="card-host-search">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Search className="w-5 h-5 text-primary" />
                  Search Hosts
                </CardTitle>
                <CardDescription>Search for hosts and view their session history</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    placeholder="Search by host name..."
                    value={hostSearch}
                    onChange={(e) => setHostSearch(e.target.value)}
                    className="flex-1"
                    data-testid="input-host-search"
                  />
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card data-testid="card-host-list">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-5 h-5 text-primary" />
                    Hosts
                  </CardTitle>
                  <CardDescription>
                    {hosts?.length || 0} hosts found
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-0">
                  <ScrollArea className="h-[500px]">
                    {hosts && hosts.length > 0 ? (
                      <div className="divide-y">
                        {hosts.map((host) => (
                          <div 
                            key={host.hostId} 
                            className={`p-4 cursor-pointer hover-elevate ${selectedHost?.hostId === host.hostId ? 'bg-primary/5' : ''}`}
                            onClick={() => setSelectedHost(host)}
                            data-testid={`host-item-${host.hostId}`}
                          >
                            <div className="flex items-center justify-between gap-2 mb-2">
                              <div className="flex items-center gap-2">
                                <UserCircle className="w-5 h-5 text-muted-foreground" />
                                <span className="font-medium">{host.hostName}</span>
                              </div>
                              <Badge variant="secondary">
                                {host.totalSessions} session{host.totalSessions !== 1 ? 's' : ''}
                              </Badge>
                            </div>
                            {host.lastSessionDate && (
                              <p className="text-xs text-muted-foreground">
                                Last session: {new Date(host.lastSessionDate).toLocaleDateString()}
                              </p>
                            )}
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="p-8 text-center text-muted-foreground">
                        <Users className="w-8 h-8 mx-auto mb-2 opacity-50" />
                        <p className="text-sm">No hosts found</p>
                      </div>
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>

              <Card data-testid="card-host-details">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <UserCircle className="w-5 h-5 text-primary" />
                    Host Details
                  </CardTitle>
                  <CardDescription>
                    {selectedHost ? selectedHost.hostName : "Select a host to view details"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {selectedHost ? (
                    <div className="space-y-6">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <p className="text-sm text-muted-foreground">Total Sessions</p>
                          <p className="text-2xl font-semibold">{selectedHost.totalSessions}</p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-sm text-muted-foreground">Last Session</p>
                          <p className="text-sm font-medium">
                            {selectedHost.lastSessionDate 
                              ? new Date(selectedHost.lastSessionDate).toLocaleDateString()
                              : "N/A"
                            }
                          </p>
                        </div>
                      </div>

                      <Separator />

                      <div>
                        <h4 className="font-medium mb-3 flex items-center gap-2">
                          <History className="w-4 h-4" />
                          Session History
                        </h4>
                        <ScrollArea className="h-[300px]">
                          <div className="space-y-3">
                            {selectedHost.sessions.map((session) => (
                              <div key={session.id} className="p-3 rounded-md bg-muted/50">
                                <div className="flex items-center justify-between gap-2 mb-2">
                                  <div className="flex items-center gap-2">
                                    <Calendar className="w-4 h-4 text-muted-foreground" />
                                    <span className="text-sm font-medium">
                                      {new Date(session.completedAt).toLocaleDateString()}
                                    </span>
                                  </div>
                                  <Badge variant="outline" className="text-xs">
                                    {session.startTime} - {session.endTime}
                                  </Badge>
                                </div>
                                {session.frpSpeed && (
                                  <div className="flex flex-wrap gap-2 mb-2">
                                    <Badge variant="secondary" className="text-xs">FRP: {session.frpSpeed}</Badge>
                                    <Badge variant="secondary" className="text-xs">PT: {session.peacetimeStatus}</Badge>
                                  </div>
                                )}
                                {session.notes && session.notes !== "No notes provided" && (
                                  <div className="flex items-start gap-2 mt-2">
                                    <FileText className="w-3 h-3 text-muted-foreground mt-0.5" />
                                    <p className="text-xs text-muted-foreground">{session.notes}</p>
                                  </div>
                                )}
                                <div className="flex items-center gap-2 mt-2">
                                  <Users className="w-3 h-3 text-muted-foreground" />
                                  <span className="text-xs text-muted-foreground">
                                    {session.reactionCount} reactions
                                  </span>
                                </div>
                              </div>
                            ))}
                          </div>
                        </ScrollArea>
                      </div>
                    </div>
                  ) : (
                    <div className="py-12 text-center text-muted-foreground">
                      <UserCircle className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p className="text-sm">Select a host from the list to view their session history</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="logs" className="space-y-6">
            <Card data-testid="card-session-logs">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-primary" />
                  Session Logs
                </CardTitle>
                <CardDescription>Complete history of all logged sessions</CardDescription>
              </CardHeader>
              <CardContent>
                {completedSessions && completedSessions.length > 0 ? (
                  <div className="space-y-4">
                    {completedSessions.map((session) => (
                      <Card key={session.id} className="overflow-hidden" data-testid={`session-log-${session.id}`}>
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between gap-4 flex-wrap mb-3">
                            <div>
                              <div className="flex items-center gap-2 mb-1">
                                <UserCircle className="w-4 h-4 text-muted-foreground" />
                                <span className="font-medium">{session.hostName}</span>
                              </div>
                              <p className="text-xs text-muted-foreground">
                                {new Date(session.completedAt).toLocaleString()}
                              </p>
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge variant="outline">
                                {session.startTime} - {session.endTime}
                              </Badge>
                              <Badge variant="secondary">
                                {session.reactionCount} reactions
                              </Badge>
                            </div>
                          </div>

                          {session.frpSpeed && (
                            <div className="flex flex-wrap gap-2 mb-3">
                              <Badge variant="secondary" className="text-xs">FRP: {session.frpSpeed}</Badge>
                              <Badge variant="secondary" className="text-xs">Peacetime: {session.peacetimeStatus}</Badge>
                              <Badge variant="secondary" className="text-xs">Speed Limit: {session.speedLimit}</Badge>
                              <Badge variant="secondary" className="text-xs">House Claiming: {session.houseClaiming}</Badge>
                            </div>
                          )}

                          {session.notes && session.notes !== "No notes provided" && (
                            <div className="p-3 rounded-md bg-muted/50">
                              <div className="flex items-start gap-2">
                                <FileText className="w-4 h-4 text-muted-foreground mt-0.5" />
                                <p className="text-sm text-muted-foreground">{session.notes}</p>
                              </div>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="py-12 text-center text-muted-foreground">
                    <FileText className="w-12 h-12 mx-auto mb-3 opacity-50" />
                    <p className="text-sm">No sessions have been logged yet</p>
                    <p className="text-xs mt-1">Sessions are logged when hosts use the /session-over command</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <Card data-testid="card-commands">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5 text-primary" />
                  Register Commands
                </CardTitle>
                <CardDescription>
                  Register slash commands to your Discord server
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="guildId">Guild ID (optional - leave empty for global)</Label>
                  <Input
                    id="guildId"
                    placeholder="Enter Discord server ID for instant registration"
                    value={guildId}
                    onChange={(e) => setGuildId(e.target.value)}
                    data-testid="input-guild-id"
                  />
                  <p className="text-xs text-muted-foreground">
                    Tip: Guild-specific commands update instantly. Global commands may take up to an hour.
                  </p>
                </div>
                <Button 
                  onClick={handleRegisterCommands}
                  disabled={registerMutation.isPending || !botStatus?.isReady}
                  data-testid="button-register"
                >
                  {registerMutation.isPending ? "Registering..." : "Register Commands"}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

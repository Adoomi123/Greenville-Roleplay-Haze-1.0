# Greenville Roleplay Haze Discord Bot

## Overview

This is a full-stack application consisting of a Discord bot for managing Greenville Roleplay sessions and a web dashboard for monitoring bot activity. The Discord bot handles session lifecycle management (startup, setup, early access, release, reinvites, ended) with role-based access control and interactive embeds. The web dashboard provides real-time visibility into bot status and active sessions.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Application Structure

**Monorepo Architecture**: The codebase uses a shared monorepo structure with three main directories:
- `client/` - React-based web dashboard
- `server/` - Express backend with Discord bot integration
- `shared/` - Shared TypeScript types and schemas

**Build System**: Custom build script using esbuild for server bundling and Vite for client bundling, allowing selective dependency bundling to optimize cold start times.

### Frontend Architecture

**UI Framework**: React with TypeScript, using Wouter for client-side routing (single-page application with dashboard and 404 pages).

**Component Library**: shadcn/ui components built on Radix UI primitives, providing a comprehensive set of accessible UI components (buttons, cards, dialogs, forms, etc.).

**Styling**: Tailwind CSS with a custom design system using CSS variables for theming. The design supports both light and dark modes with extensive color customization options.

**State Management**: TanStack Query (React Query) for server state management with custom query client configuration, including:
- Infinite stale time (no automatic refetching)
- Disabled window focus refetching
- Custom unauthorized handling (401 responses)

**Type Safety**: Full TypeScript coverage with path aliases (@/, @shared/, @assets/) for clean imports.

### Backend Architecture

**Server Framework**: Express.js with TypeScript, providing RESTful API endpoints.

**Discord Integration**: Discord.js v14 bot with:
- Gateway intents for guilds, messages, reactions, and members
- Slash command system
- Interactive components (buttons, select menus)
- Message reaction tracking
- Role-based permission system

**Session Management**: In-memory storage implementation (MemStorage class) tracking:
- Session lifecycle states (startup → setup → early_access → released → reinvites → ended)
- User reactions and permissions
- Vehicle registrations
- Session metadata (host, channel, links, game settings)

**API Design**: REST endpoints for:
- Bot status monitoring (`/api/bot/status`)
- Session retrieval (`/api/sessions`, `/api/sessions/active`)
- Command registration (`/api/bot/register-commands`)
- Vehicle management (`/api/vehicles/:userId`)

**Request Logging**: Custom middleware logging all API requests with timestamps and response times.

### Data Storage Solutions

**Current Implementation**: In-memory storage using Map data structures for sessions and vehicle registrations. This provides fast access but data is not persisted across restarts.

**Database Schema Preparation**: The codebase includes Drizzle ORM configuration and schema definitions for PostgreSQL migration:
- `drizzle.config.ts` configured for PostgreSQL dialect
- Schema types defined in `shared/schema.ts`
- Migration directory structure ready (`./migrations`)
- Environment variable placeholder for `DATABASE_URL`

**Data Models**:
- SessionState: Tracks session lifecycle with host info, channel IDs, game settings, and user reactions
- VehicleRegistration: Links Discord users to registered vehicles with plate numbers
- User: Basic user authentication structure (currently unused)

### Authentication and Authorization

**Discord Role-Based Access Control**: The bot enforces permissions using Discord role IDs:
- Early Access role (1428832378041794570)
- Public Services role (1407661660545745101)
- Staff Team role (1336441366120501421)
- Server Booster role (1412881149910450407)
- Civilian role (1428793843184046151)

**Button Interaction Security**: Interactive buttons validate user roles before allowing actions, with custom error messages for unauthorized access.

**Reaction Tracking**: Users must react to startup messages before accessing session links, tracked in-memory per session.

**Web Dashboard**: Currently no authentication implemented - endpoints are publicly accessible.

### External Dependencies

**Discord Platform**: 
- Discord.js library for bot functionality
- Discord API v10 via REST client
- Discord gateway for real-time events
- Custom emoji IDs for visual branding

**UI Component Libraries**:
- Radix UI primitives for accessible components
- Embla Carousel for carousel functionality
- date-fns for date manipulation
- lucide-react for icon components

**Form Handling**: 
- react-hook-form with @hookform/resolvers
- Zod for schema validation
- drizzle-zod for database schema validation

**Development Tools**:
- Vite for development server and HMR
- esbuild for production server bundling
- Replit-specific plugins for dev banner and error overlays
- Drizzle Kit for database migrations

**Session Management Preparation**: 
- connect-pg-simple for PostgreSQL session store (not yet active)
- express-session middleware configured

**Styling Dependencies**:
- Tailwind CSS with PostCSS
- class-variance-authority for variant-based styling
- clsx and tailwind-merge for className utilities

### Design System

**Discord-First Design**: All user-facing components designed for Discord's embed system with:
- Consistent embed color (#5c99bb teal blue)
- Custom emoji-based visual hierarchy
- Dark mode optimized design
- Structured embed layouts with headers, content sections, and footers

**Web Dashboard Design**: Modern dark theme interface using the New York shadcn/ui style with:
- Neutral base colors
- Custom border radius system
- Shadow-based elevation
- Responsive layouts with mobile support
import express from "express";
const app = express();

app.get("/", (req, res) => {
  res.send("Website + Bot are running!");
});

app.listen(3000, () => {
  console.log("Web server is live on port 3000");
});
